enum PolicyStatus {
  pending,
  insurancePending, // For direct insurance requests
  accepted, // UNLOCKS payment button
  paid,     // Client completed payment → receipt sent to operator
  rejected,
  modificationRequested,
}
