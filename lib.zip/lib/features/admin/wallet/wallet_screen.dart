import 'package:flutter/material.dart';
import 'package:tameenidz/core/theme/app_colors_extension.dart';
import 'package:go_router/go_router.dart';
import 'package:tameenidz/core/router/app_routes.dart';
import 'package:tameenidz/generated/l10n/app_localizations.dart';
import 'package:tameenidz/features/admin/widgets/admin_shared_widgets.dart';
import 'package:tameenidz/features/shared/widgets/animations/staggered_list_item.dart';
import 'package:tameenidz/core/theme/app_colors.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F0E8),
      appBar: buildAdminAppBar(context, l10n.totalWallet),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBalanceCard(context, l10n),
            const SizedBox(height: 24),
            Text(
              l10n.recentActivity,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF2D1F0E), fontFamily: 'Cairo'),
            ),
            const SizedBox(height: 12),
            _buildActivityList(context, l10n),
          ],
        ),
      ),
    );
  }

  Widget _buildBalanceCard(BuildContext context, AppLocalizations l10n) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF2D1F0E),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF2D1F0E).withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            l10n.availableBalance,
            style: const TextStyle(color: Color(0xFF8B7355), fontSize: 13, fontFamily: 'Cairo'),
          ),
          const SizedBox(height: 4),
          Text(
            '1,250,000 ${l10n.dzd}',
            style: const TextStyle(color: Color(0xFFC9A96E), fontSize: 28, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: 200,
            height: 40,
            child: ElevatedButton(
              onPressed: () => context.push(AppRoutes.adminWallet + '/withdraw'), // Fixed navigation
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFC9A96E),
                foregroundColor: Color(0xFF2D1F0E),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                elevation: 0,
              ),
              child: Text(l10n.withdraw, style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Cairo')),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityList(BuildContext context, AppLocalizations l10n) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: 5,
      itemBuilder: (context, index) {
        return StaggeredListItem(
          delay: Duration(milliseconds: index * 50),
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: context.colors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5DDD0), width: 0.5),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    color: Color(0xFFF5F0E8),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.arrow_downward, color: Color(0xFFC9A96E), size: 16),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(l10n.commissionsAdmin, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2D1F0E), fontSize: 13, fontFamily: 'Cairo')),
                      Text('${l10n.insurancePlan} #45821', style: const TextStyle(color: Color(0xFF8B7355), fontSize: 11, fontFamily: 'Cairo')),
                    ],
                  ),
                ),
                Text('+2,500 ${l10n.dzd}', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFC9A96E), fontSize: 13, fontFamily: 'Cairo')),
              ],
            ),
          ),
        );
      },
    );
  }
}
