import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:tameenidz/core/theme/app_colors_extension.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:url_launcher/url_launcher.dart';
import 'package:tameenidz/core/theme/premium_tokens.dart';
import 'package:tameenidz/features/shared/widgets/page_entry_animation.dart';
import 'package:tameenidz/features/shared/widgets/status_badge.dart';
import 'package:tameenidz/features/shared/widgets/receipt_ticket.dart';
import 'package:tameenidz/features/shared/enums/policy_status.dart';
import 'package:tameenidz/features/shared/providers/operator_providers.dart';
import 'package:tameenidz/features/shared/data/policy_repository.dart';
import 'package:tameenidz/features/shared/domain/models/policy_model.dart';
import 'package:tameenidz/generated/l10n/app_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AiApplicationDetailScreen extends ConsumerStatefulWidget {
  final String id;

  const AiApplicationDetailScreen({super.key, required this.id});

  @override
  ConsumerState<AiApplicationDetailScreen> createState() => _AiApplicationDetailScreenState();
}

class _AiApplicationDetailScreenState extends ConsumerState<AiApplicationDetailScreen> {
  final _reasonCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  PlatformFile? _finalPolicyFile;
  bool _loading = false;

  @override
  void dispose() {
    _reasonCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _openDocument(String urlOrPath) async {
    if (urlOrPath.isEmpty) return;
    
    try {
      setState(() => _loading = true);
      String finalUrl = urlOrPath;
      
      String path = urlOrPath;
      if (path.contains('/storage/v1/object/public/documents/')) {
        path = path.split('/storage/v1/object/public/documents/').last;
      } else if (path.contains('/storage/v1/object/sign/documents/')) {
        path = path.split('/storage/v1/object/sign/documents/').last.split('?').first;
      }
      
      if (!path.startsWith('http')) {
        finalUrl = await Supabase.instance.client.storage
            .from('documents')
            .createSignedUrl(path, 60);
      }

      final uri = Uri.parse(finalUrl);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        throw 'Could not launch $urlOrPath';
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('خطأ أثناء فتح المستند: $e', style: GoogleFonts.ibmPlexSansArabic()),
            backgroundColor: kStatusRejected,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final policyAsync = ref.watch(policyDetailStreamProvider(widget.id));
    final l10n = AppLocalizations.of(context)!;
    final isEn = Localizations.localeOf(context).languageCode == 'en';

    return Directionality(
      textDirection: isEn ? TextDirection.ltr : TextDirection.rtl,
      child: Scaffold(
        backgroundColor: kIvory,
        appBar: AppBar(
          backgroundColor: kIvory,
          elevation: 0,
          centerTitle: true,
          title: Column(
            children: [
              Text(
                isEn ? l10n.requestDetails : 'تفاصيل طلب المشترك',
                style: GoogleFonts.amiri(color: const Color(0xFF1B4F72), fontWeight: FontWeight.bold, fontSize: 18),
              ),
              Text(
                isEn ? l10n.algeriaUnited : 'الجزائر المتحدة (الاتحاد)',
                style: GoogleFonts.ibmPlexSansArabic(color: kInkMuted, fontSize: 10, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_forward_rounded, size: 24, color: Color(0xFF1B4F72)),
            onPressed: () => context.pop(),
          ),
        ),
        body: PageEntryAnimation(
          child: policyAsync.when(
            data: (policy) => policy == null ? Center(child: Text(l10n.noData)) : _buildContent(policy, l10n),
            loading: () => const Center(child: CircularProgressIndicator(color: Color(0xFF1B4F72))),
            error: (err, _) => Center(child: Text('Error: $err')),
          ),
        ),
        bottomNavigationBar: policyAsync.when(
          data: (policy) => policy != null ? _buildBottomActions(policy, l10n) : const SizedBox.shrink(),
          loading: () => const SizedBox.shrink(),
          error: (_, __) => const SizedBox.shrink(),
        ),
      ),
    );
  }

  Widget _buildContent(PolicyModel policy, AppLocalizations l10n) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              StatusBadge(status: policy.status),
              Text(
                'رمز الطلب: ${policy.id.substring(0, 8).toUpperCase()}',
                style: GoogleFonts.ibmPlexSansArabic(color: kInkMuted, fontSize: 12, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 24),

          _buildSectionTitle('المعلومات الشخصية للمشترك'),
          const SizedBox(height: 12),
          _buildInfoCard(
            title: policy.applicantName, // Client name logic
            subtitle: 'معلومات الهوية والاتصال الموثقة',
            details: [
              (l10n.phoneLabel, policy.applicantPhone ?? '—'),
              (l10n.ninLabel, policy.nin ?? '—'),
            ],
          ),

          const SizedBox(height: 24),
          _buildSectionTitle('تفاصيل الخدمة المطلوبة'),
          const SizedBox(height: 12),
          _buildInfoCard(
            title: policy.planName ?? 'خدمة غير محددة',
            subtitle: 'المبلغ المقدر والتاريخ',
            details: [
              ('المبلغ:', '${NumberFormat('#,###').format(policy.amount)} دج'),
              ('تاريخ الطلب:', DateFormat('yyyy/MM/dd').format(policy.submittedAt)),
            ],
          ),

          const SizedBox(height: 24),
          _buildSectionTitle('المستندات المرفقة'),
          const SizedBox(height: 12),
          _buildDocumentsGrid(policy, l10n),

          const SizedBox(height: 32),
          if (policy.status == PolicyStatus.pending || policy.status == PolicyStatus.insurancePending) ...[
            if (policy.status == PolicyStatus.insurancePending) ...[
              _buildSectionTitle('وثيقة التأمين النهائية'),
              const SizedBox(height: 12),
              InkWell(
                onTap: _loading ? null : _pickFinalPolicyFile,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: _finalPolicyFile != null ? context.colors.primaryGreen : kParchment, width: 2)),
                  child: Row(
                    children: [
                      Icon(_finalPolicyFile != null ? Icons.check_circle_rounded : Icons.upload_file_rounded, color: _finalPolicyFile != null ? context.colors.primaryGreen : const Color(0xFF1B4F72)),
                      const SizedBox(width: 12),
                      Expanded(child: Text(_finalPolicyFile != null ? _finalPolicyFile!.name : 'اضغط لرفع وثيقة التأمين (PDF)', style: GoogleFonts.ibmPlexSansArabic(fontSize: 13, fontWeight: FontWeight.bold))),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],
            if (policy.status == PolicyStatus.pending) ...[
              Text('التسعيرة النهائية (دج):', style: GoogleFonts.ibmPlexSansArabic(fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextField(
                controller: _amountCtrl,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: 'أدخل المبلغ النهائي للتسعيرة',
                  filled: true,
                  fillColor: kCream,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 16),
            ],
            Text('قرار المشغل والملاحظات:', style: GoogleFonts.ibmPlexSansArabic(fontSize: 14, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              controller: _reasonCtrl,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'اكتب ملاحظات القبول أو الرفض هنا...',
                filled: true,
                fillColor: kCream,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
          ],
          SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(title, style: GoogleFonts.amiri(fontSize: 17, fontWeight: FontWeight.bold, color: const Color(0xFF1B4F72)));
  }

  Widget _buildInfoCard({required String title, required String subtitle, required List<(String, String)> details}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: context.colors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: kParchment), boxShadow: [kCardShadow]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const CircleAvatar(backgroundColor: Color(0xFFEBF5FB), child: Icon(Icons.person_rounded, color: Color(0xFF1B4F72))),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: GoogleFonts.ibmPlexSansArabic(fontWeight: FontWeight.bold, fontSize: 15)),
                  Text(subtitle, style: GoogleFonts.ibmPlexSansArabic(fontSize: 11, color: kInkMuted)),
                ],
              ),
            ],
          ),
          const Divider(height: 24),
          ...details.map((d) => Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(d.$1, style: GoogleFonts.ibmPlexSansArabic(fontSize: 13, color: kInkMuted)),
                Text(d.$2, style: GoogleFonts.ibmPlexSansArabic(fontSize: 13, fontWeight: FontWeight.bold)),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildDocumentsGrid(PolicyModel policy, AppLocalizations l10n) {
    final docs = policy.documentUrls;
    if (docs == null || docs.isEmpty) {
      return const Text('لا توجد وثائق مرفوعة.');
    }

    final allDocs = docs.cast<Map<String, dynamic>>().map((d) => {
      'label': (d['label'] ?? 'وثيقة') as String,
      'url': (d['url'] ?? '') as String,
    }).toList();

    if (allDocs.isEmpty) return const Text('لا توجد وثائق مرفوعة.');
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.2),
      itemCount: allDocs.length,
      itemBuilder: (context, index) {
        final doc = allDocs[index];
        return InkWell(
          onTap: () => _openDocument(doc['url'] ?? ''),
          child: Container(
            decoration: BoxDecoration(color: context.colors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: kParchment)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.file_copy_rounded, color: Color(0xFF1B4F72)),
                SizedBox(height: 8),
                Text(doc['label'] ?? 'وثيقة', style: GoogleFonts.ibmPlexSansArabic(fontSize: 11, fontWeight: FontWeight.bold)),
                Text('اضغط للمعاينة', style: GoogleFonts.ibmPlexSansArabic(fontSize: 9, color: kGoldDeep)),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildBottomActions(PolicyModel policy, AppLocalizations l10n) {
    if (policy.status != PolicyStatus.pending && policy.status != PolicyStatus.insurancePending) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      decoration: BoxDecoration(color: context.colors.surface, border: Border(top: BorderSide(color: kParchment))),
      child: Row(
        children: [
          Expanded(child: _actionBtn('رفض', kStatusRejected, () => _decide(policy, PolicyStatus.rejected))),
          const SizedBox(width: 12),
          if (policy.status == PolicyStatus.pending) ...[
            Expanded(child: _actionBtn('طلب تعديل', kStatusMod, () => _decide(policy, PolicyStatus.modificationRequested))),
            const SizedBox(width: 12),
            Expanded(child: _actionBtn('قبول', kStatusAccepted, () => _decide(policy, PolicyStatus.accepted))),
          ] else ...[
            Expanded(child: _actionBtn('إصدار البوليصة', kStatusAccepted, () => _issueInsurance(policy))),
          ],
        ],
      ),
    );
  }

  Widget _actionBtn(String label, Color color, VoidCallback onTap) {
    return ElevatedButton(
      onPressed: _loading ? null : onTap,
      style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white, elevation: 0),
      child: Text(label, style: GoogleFonts.ibmPlexSansArabic(fontWeight: FontWeight.bold, fontSize: 12)),
    );
  }

  Future<void> _pickFinalPolicyFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      withData: kIsWeb,
    );
    if (result != null && result.files.isNotEmpty) {
      setState(() => _finalPolicyFile = result.files.first);
    }
  }

  Future<void> _issueInsurance(PolicyModel policy) async {
    if (_finalPolicyFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرجاء رفع وثيقة التأمين النهائية')));
      return;
    }
    setState(() => _loading = true);
    try {
      final repo = ref.read(policyRepositoryProvider);
      final fileData = kIsWeb ? _finalPolicyFile!.bytes! : File(_finalPolicyFile!.path!);
      await repo.uploadFinalPolicyDocument(widget.id, fileData, fileName: _finalPolicyFile!.name);
      await repo.updatePolicyStatus(widget.id, PolicyStatus.accepted, notes: _reasonCtrl.text);
      if (mounted) context.pop();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _decide(PolicyModel policy, PolicyStatus newStatus) async {
    if (newStatus != PolicyStatus.accepted && _reasonCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرجاء كتابة السبب في الملاحظات')));
      return;
    }

    double? amount;
    if (newStatus == PolicyStatus.accepted) {
      if (policy.status == PolicyStatus.pending) {
        amount = double.tryParse(_amountCtrl.text.trim());
        if (amount == null || amount <= 0) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('الرجاء إدخال تسعيرة صحيحة قبل القبول'),
            ),
          );
          return;
        }
      } else {
        amount = policy.amount;
      }
    }

    setState(() => _loading = true);
    try {
      await ref.read(policyRepositoryProvider).updatePolicyStatus(widget.id, newStatus, notes: _reasonCtrl.text, amount: amount);
      if (mounted) context.pop();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}
