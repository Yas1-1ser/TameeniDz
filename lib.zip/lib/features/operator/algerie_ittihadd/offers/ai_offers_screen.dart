import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import 'package:tameenidz/core/theme/premium_tokens.dart';
import 'package:tameenidz/features/shared/widgets/animations/staggered_list_item.dart';
import 'package:tameenidz/features/shared/widgets/spring_button.dart';
import 'package:tameenidz/features/shared/widgets/page_entry_animation.dart';
import 'package:tameenidz/features/shared/widgets/portal_layout.dart';
import 'package:tameenidz/features/shared/domain/models/plan_model.dart';
import 'package:tameenidz/features/shared/providers/offer_providers.dart';
import 'package:tameenidz/features/operator/offers/widgets/operator_offer_card.dart';
import 'package:tameenidz/generated/l10n/app_localizations.dart';

class AiOffersScreen extends ConsumerStatefulWidget {
  const AiOffersScreen({super.key});

  @override
  ConsumerState<AiOffersScreen> createState() => _AiOffersScreenState();
}

class _AiOffersScreenState extends ConsumerState<AiOffersScreen> {
  void _showOfferForm({PlanModel? offer}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AiOfferFormBottomSheet(
          companyEn: 'Al Ittihad',
          existingOffer: offer,
        ),
      ),
    );
  }

  Future<void> _toggleBestValue(PlanModel offer, bool value) async {
    try {
      await ref.read(offerRepositoryProvider).updateOffer(offer.id, {
        'is_best_value': value,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            value ? 'تم تحديد العرض كأفضل قيمة' : 'تم إلغاء تحديد أفضل قيمة',
            style: GoogleFonts.ibmPlexSansArabic(),
          ),
          backgroundColor: kStatusAccepted,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('خطأ أثناء التحديث: $e', style: GoogleFonts.ibmPlexSansArabic()),
          backgroundColor: kStatusRejected,
        ),
      );
    }
  }

  Future<void> _confirmDelete(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          backgroundColor: kIvory,
          title: Text(
            'تأكيد الحذف',
            style: GoogleFonts.amiri(fontWeight: FontWeight.bold, color: kGoldDeep),
          ),
          content: Text(
            'هل أنت متأكد من رغبتك في حذف هذا العرض نهائياً؟',
            style: GoogleFonts.ibmPlexSansArabic(color: kInk),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(kRadiusMd),
            side: const BorderSide(color: kParchment),
          ),
          actions: [
            SpringButton(
              child: TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(
                  'إلغاء',
                  style: GoogleFonts.ibmPlexSansArabic(color: kInkMuted, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SpringButton(
              child: TextButton(
                onPressed: () => Navigator.pop(context, true),
                style: TextButton.styleFrom(foregroundColor: kStatusRejected),
                child: Text(
                  'حذف العرض',
                  style: GoogleFonts.ibmPlexSansArabic(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );

    if (confirmed == true) {
      try {
        await ref.read(offerRepositoryProvider).deleteOffer(id);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('تم حذف العرض بنجاح', style: GoogleFonts.ibmPlexSansArabic()),
            backgroundColor: kStatusAccepted,
          ),
        );
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('خطأ أثناء الحذف: $e', style: GoogleFonts.ibmPlexSansArabic()),
            backgroundColor: kStatusRejected,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final offersAsync = ref.watch(offersStreamProvider('Al Ittihad'));
    final l10n = AppLocalizations.of(context)!;

    final menuItems = [
      (
        Icons.dashboard_rounded,
        l10n.dashboard,
        '/ai/dashboard',
      ),
      (
        Icons.account_balance_wallet_rounded,
        l10n.surplus,
        '/ai/surplus',
      ),
      (
        Icons.archive_outlined,
        l10n.policies,
        '/ai/policies',
      ),
      (
        Icons.receipt_long_outlined,
        l10n.claims,
        '/ai/claims',
      ),
      (
        Icons.local_offer_outlined,
        l10n.manageOffers,
        '/ai/offers',
      ),
      (
        Icons.settings_outlined,
        l10n.settings,
        '/ai/settings',
      ),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: PortalLayout(
        selectedIndex: 4,
        portalTitle: 'الاتحاد الجزائري',
        portalSubtitle: 'إدارة العروض الترويجية',
        accentColor: kGoldDeep,
        appBarColor: kIvory,
        appBarTextColor: kGoldDeep,
        selectedItemColor: kGoldDeep,
        selectedItemBgColor: kCream,
        unselectedItemColor: kInkMuted,
        sidebarBgColor: kIvory,
        menuItems: menuItems,
        floatingActionButton: FloatingActionButton(
          onPressed: () => _showOfferForm(),
          backgroundColor: kGoldDeep,
          child: const Icon(Icons.add, color: kIvory),
        ),
        body: PageEntryAnimation(
          child: offersAsync.when(
            data: (offers) {
              if (offers.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.local_offer_outlined, size: 64, color: kParchment),
                      const SizedBox(height: 16),
                      Text(
                        l10n.noOffersYet,
                        style: GoogleFonts.ibmPlexSansArabic(
                          color: kInkMuted,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                );
              }
              return ListView.builder(
                padding: const EdgeInsets.all(20),
                itemCount: offers.length,
                itemBuilder: (context, index) {
                  final offer = offers[index];
                  return StaggeredListItem(
                    delay: Duration(milliseconds: index * 80),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 14),
                      decoration: BoxDecoration(
                        color: kCream,
                        borderRadius: BorderRadius.circular(kRadiusMd),
                        border: Border.all(color: kParchment),
                        boxShadow: [kCardShadow],
                      ),
                      child: OperatorOfferCard(
                        plan: offer,
                        onEdit: () => _showOfferForm(offer: offer),
                        onDelete: () => _confirmDelete(offer.id),
                        onToggleBestValue: (val) => _toggleBestValue(offer, val),
                      ),
                    ),
                  );
                },
              );
            },
            loading: () => const Center(
              child: CircularProgressIndicator(color: kGoldDeep),
            ),
            error: (err, _) => Center(
              child: Text(
                'خطأ: $err',
                style: GoogleFonts.ibmPlexSansArabic(color: kStatusRejected),
              ),
            ),
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: 2, // Policies / Claims
          onTap: (idx) {
            if (idx == 0) context.go('/ai/dashboard');
            if (idx == 1) context.go('/ai/surplus');
            if (idx == 2) context.go('/ai/policies');
            if (idx == 3) context.go('/ai/settings');
          },
          type: BottomNavigationBarType.fixed,
          selectedItemColor: kGoldDeep,
          unselectedItemColor: kInkMuted,
          backgroundColor: kIvory,
          selectedLabelStyle: GoogleFonts.ibmPlexSansArabic(fontWeight: FontWeight.bold),
          unselectedLabelStyle: GoogleFonts.ibmPlexSansArabic(),
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.home_filled),
              label: l10n.dashboard,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.account_balance_wallet_rounded),
              label: l10n.surplus,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.archive_outlined),
              label: l10n.policies,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.person_outline),
              label: l10n.profile,
            ),
          ],
        ),
      ),
    );
  }
}

class AiOfferFormBottomSheet extends ConsumerStatefulWidget {
  final String companyEn;
  final PlanModel? existingOffer;

  const AiOfferFormBottomSheet({
    super.key,
    required this.companyEn,
    this.existingOffer,
  });

  @override
  ConsumerState<AiOfferFormBottomSheet> createState() => _AiOfferFormBottomSheetState();
}

class _AiOfferFormBottomSheetState extends ConsumerState<AiOfferFormBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _premiumController;
  late TextEditingController _coverageController;
  late TextEditingController _tabarruController;
  late TextEditingController _surplusController;
  late TextEditingController _durationController;
  late bool _isBestValue;
  late String _iconType;

  @override
  void initState() {
    super.initState();
    final offer = widget.existingOffer;
    _nameController = TextEditingController(text: offer?.companyName ?? '');
    _premiumController = TextEditingController(
      text: offer?.premium.replaceAll(RegExp(r'[^0-9.]'), '') ?? '',
    );
    _coverageController = TextEditingController(text: offer?.coverage ?? '');
    _tabarruController = TextEditingController(
      text: offer?.tabarruRate.replaceAll('%', '') ?? '',
    );
    _surplusController = TextEditingController(
      text: offer?.surplusRate.replaceAll('%', '') ?? '',
    );
    _durationController = TextEditingController(
      text: offer?.claimsDuration.replaceAll(RegExp(r'[^0-9]'), '') ?? '',
    );
    _isBestValue = offer?.isBestValue ?? false;
    _iconType = offer?.iconType ?? 'shield';
  }

  @override
  void dispose() {
    _nameController.dispose();
    _premiumController.dispose();
    _coverageController.dispose();
    _tabarruController.dispose();
    _surplusController.dispose();
    _durationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: kIvory,
        borderRadius: BorderRadius.vertical(top: Radius.circular(kRadiusLg)),
      ),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 24,
        right: 24,
        top: 24,
      ),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: kParchment,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                widget.existingOffer == null ? 'إضافة عرض ترويجي جديد' : 'تعديل بيانات العرض',
                style: GoogleFonts.amiri(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: kGoldDeep,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              _buildField(_nameController, 'اسم العرض الترويجي', Icons.edit),
              const SizedBox(height: 16),
              if (_iconType != 'rafik')
                _buildField(
                  _premiumController,
                  'قيمة قسط الاشتراك (د.ج)',
                  Icons.payments_outlined,
                  isNumeric: true,
                ),
              if (_iconType == 'rafik')
                _buildField(
                  _tabarruController,
                  'نسبة التبرع المقترحة للمشترك',
                  Icons.percent,
                  isNumeric: true,
                ),
              const SizedBox(height: 16),
              _buildField(
                _coverageController,
                'حد التغطية المالية للتعويضات',
                Icons.shield_outlined,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _buildField(
                      _tabarruController,
                      'نسبة صندوق التبرع (٪)',
                      Icons.volunteer_activism_outlined,
                      isNumeric: true,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildField(
                      _surplusController,
                      'نسبة الفائض الموزع (٪)',
                      Icons.account_balance_wallet_outlined,
                      isNumeric: true,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              _buildField(
                _durationController,
                'مدة تسوية المطالبات (بالأيام)',
                Icons.timer_outlined,
                isNumeric: true,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _iconType == 'rafik' || _iconType == 'shield' || _iconType == 'verified'
                    ? _iconType
                    : 'shield',
                dropdownColor: kIvory,
                style: GoogleFonts.ibmPlexSansArabic(color: kInk),
                decoration: _inputDecoration(
                  'رمز العرض الترويجي',
                  Icons.category_outlined,
                ),
                items: const [
                  DropdownMenuItem(value: 'shield', child: Text('درع الحماية (Shield)')),
                  DropdownMenuItem(value: 'verified', child: Text('معتمد وموثق (Verified)')),
                  DropdownMenuItem(value: 'rafik', child: Text('الرفيق المساعد (Rafik)')),
                ],
                onChanged: (v) => setState(() => _iconType = v!),
              ),
              const SizedBox(height: 16),
              SwitchListTile(
                title: Text(
                  'العرض الموصى به (أفضل قيمة للمشترك)',
                  style: GoogleFonts.ibmPlexSansArabic(
                    fontWeight: FontWeight.bold,
                    color: kInk,
                  ),
                ),
                value: _isBestValue,
                onChanged: (v) => setState(() => _isBestValue = v),
                activeColor: kGoldDeep,
                activeTrackColor: kCream,
                contentPadding: EdgeInsets.zero,
              ),
              const SizedBox(height: 24),
              SpringButton(
                child: ElevatedButton(
                  onPressed: _saveOffer,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kGoldDeep,
                    foregroundColor: kIvory,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(kRadiusSm),
                    ),
                    elevation: 0,
                  ),
                  child: Text(
                    'حفظ بيانات العرض الترويجي',
                    style: GoogleFonts.ibmPlexSansArabic(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(TextEditingController controller, String label, IconData icon, {bool isNumeric = false}) {
    return TextFormField(
      controller: controller,
      style: GoogleFonts.ibmPlexSansArabic(color: kInk),
      keyboardType: isNumeric ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
      decoration: _inputDecoration(label, icon),
      validator: (v) => v == null || v.isEmpty ? 'هذا الحقل مطلوب وملزم للمشغل' : null,
    );
  }

  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: GoogleFonts.ibmPlexSansArabic(color: kInkMuted, fontSize: 13),
      prefixIcon: Icon(icon, color: kGoldDeep, size: 20),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(kRadiusMd),
        borderSide: const BorderSide(color: kParchment),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(kRadiusMd),
        borderSide: const BorderSide(color: kParchment),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(kRadiusMd),
        borderSide: const BorderSide(color: kGoldDeep, width: 1.5),
      ),
      filled: true,
      fillColor: kCream,
    );
  }

  Future<void> _saveOffer() async {
    if (!_formKey.currentState!.validate()) return;

    final opId = widget.companyEn.toLowerCase().contains('takaful') ? 'algeria_takaful' : 'al_ittihad';
    final premiumValue = _iconType == 'rafik' ? 0.0 : double.parse(_premiumController.text);

    final data = {
      'operator_id': opId,
      'name_ar': _nameController.text,
      'name_en': widget.companyEn,
      'premium_amount': premiumValue,
      'coverage_details': _coverageController.text,
      'tabarru_rate': double.parse(_tabarruController.text) / 100,
      'surplus_rate': double.parse(_surplusController.text) / 100,
      'claims_duration': '${_durationController.text} أيام',
      'is_best_value': _isBestValue,
      'icon_type': _iconType,
    };

    try {
      if (widget.existingOffer == null) {
        await ref.read(offerRepositoryProvider).addOffer(data);
      } else {
        await ref.read(offerRepositoryProvider).updateOffer(widget.existingOffer!.id, data);
      }
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('تم حفظ العرض الترويجي بنجاح', style: GoogleFonts.ibmPlexSansArabic()),
            backgroundColor: kStatusAccepted,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('خطأ أثناء الحفظ: $e', style: GoogleFonts.ibmPlexSansArabic()),
            backgroundColor: kStatusRejected,
          ),
        );
      }
    }
  }
}
