import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:tameenidz/features/shared/domain/models/agent_model.dart';

class CommissionWalletCard extends StatelessWidget {
  final AgentModel agent;

  const CommissionWalletCard({super.key, required this.agent});

  String _formatDZD(double val) {
    return '${NumberFormat('#,###', 'ar').format(val.round())} دج';
  }

  @override
  Widget build(BuildContext context) {
    const Color accentGold = Color(0xFFC9A84C);

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A3A2A), Color(0xFF2E5E3E)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1A3A2A).withValues(alpha: 0.3),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.account_balance_wallet_outlined, color: accentGold, size: 22),
              const SizedBox(width: 8),
              Text(
                'محفظتي',
                style: TextStyle(color: Colors.white70),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            _formatDZD(agent.walletBalance),
            style: TextStyle(
              color: accentGold,
              fontWeight: FontWeight.bold,
              fontSize: 32,
            ),
          ),
          const Text(
            'الرصيد المتراكم من العمولات',
            style: TextStyle(color: Colors.white54, fontSize: 12),
          ),
          const SizedBox(height: 24),
          OutlinedButton.icon(
            onPressed: () {
              // TODO: Show withdrawal bottom sheet
            },
            icon: const Icon(Icons.arrow_downward, color: accentGold, size: 18),
            label: Text(
              'طلب سحب الأرباح',
              style: TextStyle(
                color: accentGold,
                fontWeight: FontWeight.bold,
              ),
            ),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: accentGold),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

