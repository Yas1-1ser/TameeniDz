// lib/features/operator/widgets/shared_info_cards.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tameenidz/core/theme/premium_tokens.dart';

class LegalComplianceCard extends StatelessWidget {
  const LegalComplianceCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: kCream,
        borderRadius: BorderRadius.circular(kRadiusMd),
        border: Border.all(color: kParchment, width: 1),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          title: Text(
            'لماذا نحن قانونيون؟',
            style: GoogleFonts.amiri(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: kGoldDeep,
            ),
          ),
          childrenPadding: const EdgeInsets.all(16),
          children: [
            _buildComplianceRow(
              'الأمر 95-07',
              'القانون الأم للتأمين في الجزائر',
            ),
            const Divider(color: kParchment, height: 16),
            _buildComplianceRow(
              'المرسوم 21-81',
              'دستور التكافل، الفصل المالي ونافذة التكافل',
            ),
            const Divider(color: kParchment, height: 16),
            _buildComplianceRow(
              'قرار وزارة المالية 2021',
              'يضبط عقود وتوزيع الفوائض',
            ),
            const Divider(color: kParchment, height: 16),
            _buildComplianceRow(
              'الهيئة الشرعية الوطنية',
              'رقابة شرعية على كل عقد',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildComplianceRow(String title, String subtitle) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(Icons.verified_rounded, color: kGoldMid, size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.ibmPlexSansArabic(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: kInk,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.ibmPlexSansArabic(
                  fontSize: 12,
                  color: kInkMuted,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class TakafulPhilosophyCard extends StatelessWidget {
  const TakafulPhilosophyCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: kCream,
        borderRadius: BorderRadius.circular(kRadiusMd),
        border: Border.all(color: kParchment, width: 1),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          title: Text(
            'التكافل.. حماية بروح التعاون',
            style: GoogleFonts.amiri(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: kGoldDeep,
            ),
          ),
          childrenPadding: const EdgeInsets.all(16),
          children: [
            Text(
              'نظام تأمين إسلامي يقوم على مبدأ التضامن — الجميع يشتركون في صندوق واحد لتعويض المتضررين. الشركة وكيل يدير الصندوق مقابل أجر معلوم، وليست مالكة لأموال المشتركين.',
              style: GoogleFonts.ibmPlexSansArabic(
                fontSize: 13,
                color: kInkMuted,
                height: 1.7,
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _buildChip('الوكالة'),
                _buildChip('الرقابة الشرعية'),
                _buildChip('صندوق المشتركين'),
                _buildChip('التكافل الاجتماعي'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: kParchment,
        borderRadius: BorderRadius.circular(kRadiusSm),
      ),
      child: Text(
        label,
        style: GoogleFonts.ibmPlexSansArabic(
          fontSize: 11,
          fontWeight: FontWeight.bold,
          color: kGoldDeep,
        ),
      ),
    );
  }
}
